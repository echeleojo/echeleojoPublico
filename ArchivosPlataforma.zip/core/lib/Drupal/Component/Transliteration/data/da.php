<?php

/**
 * @file
 * Danish transliteration data for the PhpTransliteration class.
 */

$overrides['da'] = [
  0xC5 => 'Aa',
  0xD8 => 'Oe',
  0xE5 => 'aa',
  0xF8 => 'oe',
];
